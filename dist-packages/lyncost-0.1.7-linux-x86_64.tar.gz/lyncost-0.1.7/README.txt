Lyncost — Personal Finance & Investments (v0.1.7)
==================================================

Lyncost is a 100% offline, privacy-first personal finance tracker for Linux.

QUICK START:
  To run immediately without installing:
    ./lyncost

PERMANENT INSTALL (User-level, no sudo required):
    ./install.sh

UNINSTALL:
  ./uninstall.sh         (removes app, preserves database)
  ./uninstall.sh --purge (removes app and wipes all financial databases)
